#include <ros/ros.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/PoseStamped.h>

void poseUpdateCallback(const geometry_msgs::PoseWithCovarianceStamped::ConstPtr& msg)
{
    // Create a PoseStamped message and copy relevant data
    geometry_msgs::PoseStamped converted_msg;
    converted_msg.header = msg->header;
    converted_msg.pose = msg->pose.pose;
    ROS_INFO("Received pose update: x=%f, y=%f, z=%f", msg->pose.pose.position.x, msg->pose.pose.position.y, msg->pose.pose.position.z);

    // Publish the converted message
    ros::NodeHandle nh;
    ros::Publisher pub = nh.advertise<geometry_msgs::PoseStamped>("converted_poseupdate", 10);
    pub.publish(converted_msg);
}


void timerCallback(const ros::TimerEvent& event){
     ROS_INFO("Received jjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj");
}


int main(int argc, char** argv)
{
    ros::init(argc, argv, "message_bridge");
    ros::NodeHandle nh;
     
    ros::Subscriber pose_sub = nh.subscribe("poseupdate_h", 100, poseUpdateCallback);
    ros::Timer timer = nh.createTimer(ros::Duration(4), timerCallback);

    ros::spin();

    return 0;
}







