#! /usr/bin/env python

import rospy
from nav_msgs.msg import Path


def callback(msg):
    for i in msg.poses:
	    print (i.pose.position.x)

 
rospy.init_node('path_listener') #change name 
sub=rospy.Subscriber('/move_base/DWAPlannerROS/global_plan',Path,callback)
rospy.spin()






